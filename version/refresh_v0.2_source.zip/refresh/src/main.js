import Vue from 'vue';
import Main from '@/components/Main.vue';

new Vue({
    render: h => h(Main),
})
.$mount('#app');
